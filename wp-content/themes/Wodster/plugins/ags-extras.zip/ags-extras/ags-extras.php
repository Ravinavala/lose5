<?php
/**
 * Plugin Name: Aspen Grove Studios Theme Extras
 * Plugin URI: http://aspengrovestudios.com/
 * Description: 
 * Version: 1.0.1
 * Author: Aspen Grove Studios
 * Author URI: http://aspengrovestudios.com/
 * License: GPL2
 */

$agsx_compatible_themes = array('Case-Study' => 'casestudy-options', 'Fashion' => 'fashion-options', 'Cafe' => 'cafe-options', 'Interior' => 'interior-options', 'Wodster' => 'wodster-options', 'Walden' => 'walden-options');

function agsx_wp_admin_area_customization($wp_customize)
{
    $wp_customize->add_section('agsx_login_customizer', array(
        'title' => 'Login Customizer'
    ));
    $wp_customize->add_setting('login_area_bg_image', array(
        
    ));
     $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'login_area_bg_image', array(
        'label' => __('Background Image', 'Divi'),
        'section' => 'agsx_login_customizer'
    )));
    $wp_customize->add_setting('login_form_alignment', array(
        'default' => 'none',
        'transport' => 'refresh'
    ));
    $wp_customize->add_control('login_form_alignment', array(
        'label' => 'Login Form Alignment',
        'section' => 'agsx_login_customizer',
        'placeholder' => 'Align the login logo',
        'default' => 'none',
        'type' => 'radio',
        'choices' => array(
            'left' => 'Left',
            'none' => 'Center',
            'right' => 'Right'
        )
    ));
    $wp_customize->add_setting('login_area_logo_image', array(
       
    ));
   $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'login_area_logo_image', array(
        'label' => __('Login Logo (100px x 100px in place of WP logo)', 'Divi'),
        'section' => 'agsx_login_customizer'
    )));
    $wp_customize->add_section('agsx_login_customizer', array(
        'title' => 'Login Customizer'
    ));
    $colors   = array();
    $colors[] = array(
        'slug' => 'login_background_color',
        'default' => 'rgba(0, 0, 0, 0)',
        'label' => __('Background Color', 'Divi')
    );
    $colors[] = array(
        'slug' => 'content_link_color',
        'default' => '#999',
        'label' => __('Links Color', 'Divi')
    );
    $colors[] = array(
        'slug' => 'form_background_color',
        'default' => '#ffffff',
        'label' => __('Form Background Color', 'Divi')
    );
    $colors[] = array(
        'slug' => 'background_color_tint',
        'default' => 'rgba(0, 0, 0, 0)',
        'label' => __('Background Image Tint', 'Divi')
    );
    $colors[] = array(
        'slug' => 'login_submit_color',
        'default' => '#00a0d2',
        'label' => __('Submit Button Color', 'Divi')
    );
	$colorControl = (class_exists('ET_Divi_Customize_Color_Alpha_Control') ? 'ET_Divi_Customize_Color_Alpha_Control' : 'ET_Color_Alpha_Control');
    foreach ($colors as $color) {
        $wp_customize->add_setting($color['slug'], array(
            'default' => $color['default'],
            'type' => 'option',
            'capability' => 'edit_theme_options'
        ));
        $wp_customize->add_control(new $colorControl($wp_customize, $color['slug'], array(
            'label' => $color['label'],
            'section' => 'agsx_login_customizer',
            'settings' => $color['slug']
        )));
    }
}

function agsx_custom_login_area_logo_image()
{
    return get_bloginfo('url');
}

function agsx_custom_login_area_logo_image_title()
{
    return get_bloginfo('name');
}

function agsx_filter_wp_title($title)
{
    if (is_404()) {
        $title = '404 Not Found';
    }
    return $title;
}

add_action('init', 'agsx_init', 1);
function agsx_init() {
	global $agsx_compatible_themes;
	$themeName = get_stylesheet();
	if (!isset($agsx_compatible_themes[$themeName])) {
		return;
	}
	define('AGSX_THEME', $themeName);
	define('AGSX_PARENT_MENU_SLUG', $agsx_compatible_themes[$themeName]);
	
	if (include_once(dirname(__FILE__).'/includes/agspage404.class.php')) {
		new agspage404();
	}
	
	if (is_admin()) {
		include_once(dirname(__FILE__).'/includes/admin.php');
	}
	
	add_action('login_head', 'agsx_login_head');
	add_action('customize_register', 'agsx_wp_admin_area_customization');
	add_filter('login_headerurl', 'agsx_custom_login_area_logo_image');
	add_filter('login_headertitle', 'agsx_custom_login_area_logo_image_title');
	add_filter('wp_title', 'agsx_filter_wp_title', 11);
	
	add_shortcode('custom-search-form', 'agsx_404_template_search_form');
}


function agsx_404_template_search_form() {
	ob_start();
    get_search_form( );
    $html = ob_get_contents();
    ob_end_clean();
    return $html;
}

function agsx_admin_scripts() {
    wp_enqueue_style('agsx_admin_css',  plugins_url('/css/admin.css', __FILE__));
}

function agsx_login_head() {
	wp_enqueue_style('agsx_login_style', plugins_url('/css/custom-login.css',__FILE__));
	
	echo('<style type="text/css">');
	
    $value   = get_theme_mod('login_area_bg_image');
    if (!empty($value)) {
        echo '.login, body, html { background-image: url(" ' . $value . ' ")!important; }';
    }
	
	$value   = get_theme_mod('login_area_logo_image');
    if (!empty($value)) {
        echo 'h1 a { background-image: url(" ' . $value . ' ") !important; }';
    }
	
    $value   = get_theme_mod('login_form_alignment');
    if (!empty($value)) {
        echo '#login { float: ' . $value . '!important; }';
    }
	
	$value = get_option('content_link_color');
	if (!empty($value)) {
		echo '.login #backtoblog a, #login form p label, .login #nav a, .login h1 a { color: ' . $value . '!important; }';
	}
	
	$value = get_option('login_background_color');
	if (!empty($value)) {
		echo('.login:before {background : ' . $value . '!important; }');
	}
	
	$value = get_option('form_background_color');
	if (!empty($value)) {
		echo('.login form {background: ' . $value . '!important;}');
	}
	
	$value = get_option('background_color_tint');
	if (!empty($value)) {
		echo('.login:after {background: ' . $value . ' !important;}');
	}
	
	$value = get_option('login_submit_color');
	if (!empty($value)) {
		echo('.wp-core-ui .button-primary {background: ' . $value . '!important;}');
	}
	
	echo('</style>');
}