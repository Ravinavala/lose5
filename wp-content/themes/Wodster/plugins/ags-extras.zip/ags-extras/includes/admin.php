<?php
if (!defined('ABSPATH')) die();
add_action('admin_init', 'agsx_admin_init');
function agsx_admin_init() {
	add_action('admin_enqueue_scripts', 'agsx_admin_scripts');
	
	register_setting('agsx_header_option', 'agsx_header_option');
	register_setting('agsx_404_page_option', 'agsx_404_page_option');
	register_setting('agsx_login_page_option', 'agsx_login_page_option');
	
    add_settings_section('agsx_header', 'Aspen Footer Editor', 'agsx_header_callback', 'agsx_header_option');
    add_settings_field('header_type', '', 'agsx_textbox_callback', 'agsx_header_option', 'agsx_header', array('header_type'));
    add_settings_section('agsx_404_page', 'Custom 404 Page', 'agsx_404_page_callback', 'agsx_404_page_option');
    add_settings_field('404_post', '', 'agsx_404_post_callback', 'agsx_404_page_option', 'agsx_404_page');
    add_settings_section('agsx_login_page', 'Custom Login Page', 'agsx_login_page_callback', 'agsx_login_page_option');
    add_settings_field('login_post', '', 'agsx_login_post_callback', 'agsx_login_page_option', 'agsx_login_page');
}

add_action('admin_menu', 'agsx_admin_menu', 100);
function agsx_admin_menu() {
	if (is_plugin_active('aspen-footer-editor/divi-footer-editor.php')) {
		add_submenu_page(AGSX_PARENT_MENU_SLUG, __( 'Aspen Footer Editor', 'aspen-footer-editor' ), __( 'Aspen Footer Editor', 'aspen-footer-editor' ), 'edit_footer_text', 'aspen-footer-editor', 'show_divi_footer_editor_page');
		define('AGS_DFE_IS_BUNDLED', true);
	}
	add_submenu_page(AGSX_PARENT_MENU_SLUG, __('Login Customizer', 'Divi'), __('Login Customizer', 'Divi'), 'manage_options', 'customize.php?et_customizer_option_set=theme&autofocus[section]=agsx_login_customizer&return='.urlencode(wp_unslash($_SERVER['REQUEST_URI'])));
}
function agsx_header_callback() {
    echo '<div class="demo_content_options">
	
	<p>Modifying the default footer has never been easier!<p>
	
	<p>Using the <a href="https://aspengrovestudios.com/product/divi-footer-editor/" target="_blank">Aspen Footer Editor</a> you can virtually add anything to the footer area of your website using the WYSIWYG a editor!</p>
	<h3>Features</h3>
	<ul>
	<li>Add any footer content using WYSIWYG visual Editor.</li>
	<li>Any formatted texts, images, video can be added.</li>
	<li>Shortcodes for dynamic time variables like (<em>dynamic year update</em>) are available.</li>
	<li>Inline CSS can be added. Examples have been provided in the settings page.</li>
	</ul>
	
	
	</div>';
}
function agsx_404_page_callback()
{
    echo '<div class="demo_content_options">
	
	
	<p>Make your 404 pages standout with our easy 404 template tool. You can also choose to use any existing page on your website as your custom 404 page.</p>	
	<h3>Process</h3>
	<ol>
	<li>
	Create a new page (<em>name it whatever you like</em>)</li>
	<li>Use the Page builder to design the page to your liking.</li>
	<li>Head to <strong>Template</strong> metabox under <em>Page Attributes</em> and select <strong>404 Page</strong> or <strong>404 Page Blank</strong> (<em>without site header and footer</em>).</li>
	<li>Change your site permalinks to anything other than default (<em>settings>permalinks</em>).</li>
</ol>	

<h4>Info</h4>
<ul>
<li>You cannot preview the page or see the page on its own URL being logged in. It will redirect you to the homepage.</li>
<li>Either use the Module preview tool or publish the page and then open the site in a new browser. Check any broken link and customize the template design accordingly.</li>
<li>You can use our pre-designed layout for the 404 template. You can customize the page later or create a new page.</li>
<li>404 Pages are set to <em>noindex</em> and <em>nofollow</em> by default.</li>
<ul>
	
	</div>';
}
function agsx_login_post_callback($args) {
    echo '<a class="button-primary" href="customize.php?et_customizer_option_set=theme&autofocus[section]=agsx_login_customizer&return='.urlencode(wp_unslash($_SERVER['REQUEST_URI'])).'">Go to Settings</a>';
}
function agsx_textbox_callback($args) {
    echo '<a class="button-primary" href="admin.php?page=aspen-footer-editor">Add Footer Text</a>';
}
function agsx_404_post_callback($args)
{
    echo '<a class="button-primary" href="admin.php?page=ags-404-settings">Add 404 Template</a>';
}
function agsx_login_page_callback()
{
    echo '<div class="demo_content_options">
	
	<p>Use our built-in WP Login Customizer to design a custom login page.</p>
	<h3>Features</h3>
	<ul>
		<li><strong>Background Image</strong> - Upload an image in your site and place the image URL in the background image field. (<em>External image URLs can also be used</em>).</li>
		<li><strong>Background Color</strong> - In case you wish to have a background color, use background color option and empty the background image URL field. (<em>if already placed</em>)</li>
		<li><strong>Login Form Alignment</strong>. You can align the form to the left or right or centered. The default is left.</li>
		<li><strong>WP logo</strong> - Replace the default WP logo with your own image. Place the image URL in the Login Logo field. (<em>The link will be your site homepage</em>)</li>
		<li><strong>Text and Links Color</strong> - You can change color of the texts and links using the color picker.</li>
		<li><strong>Login Form Background</strong>. You can customize the form background color using the color picker.</li>
		<li><strong>Submit Button</strong> - You can change the submit button color using the color picker.</li>
		<li><strong>Background Image Tint</strong> - You can add a tint on your background image making the login form standout.</li>
	</ul>
	</div>';
}
add_action('agsx_tabs', 'agsx_tabs', 10, 2);
function agsx_tabs($pageSlug, $activeTab) {
?>
	<?php if (defined('AGS_DFE_IS_BUNDLED')) { ?>
	<a href="?page=<?php echo($pageSlug); ?>&tab=header_options" class="nav-tab <?php
    echo $activeTab == 'header_options' ? 'nav-tab-active' : '';
?>">Footer Editor</a>
	<?php } ?>
			<a href="?page=<?php echo($pageSlug); ?>&tab=404_page_options" class="nav-tab <?php
    echo $activeTab == '404_page_options' ? 'nav-tab-active' : '';
?>">404 Template</a> 
			<a href="?page=<?php echo($pageSlug); ?>&tab=login_page_options" class="nav-tab <?php
    echo $activeTab == 'login_page_options' ? 'nav-tab-active' : '';
?>">WP Login Customizer</a>
<?php }
add_action('agsx_tab_content', 'agsx_tab_content');
function agsx_tab_content($tab) {
	if ($tab == 'header_options') {
        settings_fields('agsx_header_option');
        do_settings_sections('agsx_header_option');
    } else if ($tab == '404_page_options') {
        settings_fields('agsx_404_page_option');
        do_settings_sections('agsx_404_page_option');
    } else if ($tab == 'login_page_options') {
        settings_fields('agsx_login_page_option');
        do_settings_sections('agsx_login_page_option');
    }
}
?>