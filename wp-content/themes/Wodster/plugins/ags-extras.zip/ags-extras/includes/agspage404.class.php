<?php
if (!defined('ABSPATH')) die();
class agspage404 {

    public function __construct()

    {
        $this->get_settings();
        $this->init();
    }

    private function get_settings()

    {

        $this->settings                    = array();

        $this->settings['404page_page_id'] = $this->get_404page_id();

    }

    private function init()

    {

        add_filter('404_template', array(

            $this,

            'show404'

        ));

        add_action('admin_init', array(

            $this,

            'admin_init'

        ));

        add_action('admin_menu', array(

            $this,

            'admin_menu_404'

        ), 999);

        add_action('admin_head', array(

            $this,

            'admin_css'

        ));

    }

    function show404($template)

    {

        global $wp_query;

        $template404 = $template;

        $pageid      = $this->settings['404page_page_id'];

        if ($pageid > 0) {

            $wp_query = null;

            $wp_query = new WP_Query();

            $wp_query->query('page_id=' . $pageid);

            $wp_query->the_post();

            $template404 = get_page_template();

            rewind_posts();

        }

        return $template404;

    }

    function admin_init()

    {

        add_settings_section('404page-settings', '', array(), '404page_settings_section');

        register_setting('404page_settings', '404page_page_id');

        add_settings_field('404page_settings_404page', __('Select a page for 404 Error Template', '404page'), array(

            $this,

            'admin_404page'

        ), '404page_settings_section', '404page-settings', array(

            'label_for' => '404page_page_id'

        ));

    }

    function admin_css()

    {

        echo '<style type="text/css">#select404page" {width: 100%}</style>';

    }

    function admin_404page()

    {

        if ($this->settings['404page_page_id'] < 0) {

            echo '<div class="error form-invalid" style="line-height: 3em">' . __('The page you have selected as 404 page does not exist anymore. Please choose another page.', '404page') . '</div>';

        }

        wp_dropdown_pages(array(

            'name' => '404page_page_id',

            'id' => 'select404page',

            'echo' => 1,

            'show_option_none' => __('&mdash; NONE (WP default 404 page) &mdash;', '404page'),

            'option_none_value' => '0',

            'selected' => $this->settings['404page_page_id']

        ));

    }

    function admin_menu_404()

    {
		
        $page_handle = add_submenu_page(AGSX_PARENT_MENU_SLUG, __('404 Page Settings', "404page"), __('404 Page Settings', "404page"), 'manage_options', 'ags-404-settings', array(

            $this,

            'admin_page'

        ));

    }

    function admin_page()

    {

        if (!current_user_can('manage_options')) {

            wp_die(__('You do not have sufficient permissions to access this page.'));

        }

?>

    <div class="wrap">

      <?php

        screen_icon();

?>

      <h3><?php

        _e('404 Page', '404page');

?></h3>

      <div id="poststuff">

        <div id="post-body" class="metabox-holder columns-2">

          <div id="post-body-content">

            <div class="meta-box-sortables ui-sortable">

              <form method="post" action="options.php">

                <div class="postbox">

                  

                </div>

                <div class="postbox">

                  <div class="inside">

                    <?php

        settings_fields('404page_settings');

        do_settings_sections('404page_settings_section');

        submit_button();

		echo '<em>Please make sure your site permalinks are not set to default or else, this will not work</em>';

?>

                   

                  </div>

                </div>

              </form>

            </div>

          </div>

          

        </div>

        <br class="clear">

      </div>    

    </div>

    <?php

    }

    private function get_404page_id()

    {

        $pageid = get_option('404page_page_id', 0);

        if ($pageid != 0) {

            $page = get_post($pageid);

            if (!$page || $page->post_status != 'publish') {

                $pageid = -1;

            }

        }

        return $pageid;

    }

}
?>